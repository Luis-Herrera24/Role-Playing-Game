# Project 3

Luis Herrera (lah136) : Transfered the files from Project 2 into this new project. I worked on fixing the errors from our last project, including making sure that the program would catch errors if the wrong arguement was entered. I was also tasked with creating the BardCharacter.Java. Additiinally I helped my team by working on some of the GUI, which included the dropdown box showing the players name and winrate.

Ray Rojas (xvc3) : Created the GUI, including the frame itself, along with the buttons and the event listener actions.

Joseph Sheraden-Urrutia (jas759) : Worked on the ability classes, particularly LuteMusic, and cleaned up much of the code for better readability. Wrote and formatted documentation for all character and ability classes, as well as the GraphicalUserInterface class. Wrote release notes and generated the Javadoc. 

John Yamamoto(Jmy40) : Created the FighterCharacter.java which extends BaseCharacter and set hitPoints to 150 and armor to heavy. I also created the ShieldDefense.java which implements Abilities and added the new field failureGraphic. 

## RELEASE NOTES

Known Bugs
- FireballScroll ability casts occassionally without having been clicked on.
- Win rate only appears when the user clicks on the dropdown menu.
- Buttons appear in color for Windows users ,but not for Mac.

