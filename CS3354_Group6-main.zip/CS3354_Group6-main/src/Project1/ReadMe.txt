Luis Herrera Lah136
Filled in the constructPlayerFromInput method, as well as adding the missing instance variables 
and getther methods in the PlayerData.file.

Ray Rojas Xvc3
I filled out the constructPlayerFromElement method, and did general troubleshooting

Joseph Sheraden jas759
I wrote the setter methods for the PlayerData class and added comments in places where I felt
they were necessary. I also figured out the correct filepaths to use in order to access the
data for this project.

John Yamamoto Jmy40
I preformed the Herculean task of calling the constructor constructPlayerFromInput and send 
it the string that main was given, I also wrote the call to the addToXML constructor,
passed it the object newPlayer and parsedXML, and I also added a player to the playlist in the
populatePlayerList.
