# CS3354_Group6

Luis Herrera Lah136

Constructed the BaseCharacter class & Abilities interface. Assited with JavaDoc and troublshooting.

Ray Rojas Xvc3

Added some of the Try/Catch blocks

Joseph Sheraden jas759

Wrote the MagicCharacter class and added comments in various places.

John Yamamoto Jmy40

Created FireBallScroll that implements Abilities. 
